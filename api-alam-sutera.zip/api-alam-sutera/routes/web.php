<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It is a breeze. Simply tell Lumen the URIs it should respond to
| and give it the Closure to call when that URI is requested.
|
*/

$router->get('/', function () use ($router) {
    // return $router->app->version();
    return '';
});


$router->get('v1/user/get', 'UserController@get');
$router->get('v1/route/live', 'RouteController@fetch');


$router->post('v1/user/login', 'UserController@auth');
$router->post('v1/route/collect', 'RouteController@save');
$router->post('v1/route/checkpoint', 'RouteController@checkpoint');

