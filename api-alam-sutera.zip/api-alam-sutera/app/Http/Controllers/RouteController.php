<?php

namespace App\Http\Controllers;

use Laravel\Lumen\Routing\Controller as BaseController;
use App\TempRoute;
use App\TrackCheckPoint;
use App\Patrol;
use Illuminate\Http\Request;

class RouteController extends Controller
{
    function __construct() 
    {

    }

    function save(Request $req) {
        
        $data = [
            'cluster_id' => $req->input('cluster_id'),
            'longitude' => $req->input('longitude'),
            'latitude' => $req->input('latitude'),
            'speed' => $req->input('speed'),
            'accuracy' => $req->input('accuracy'),
            'unique_key' => $req->input('unique_key'),
            'device_date' => $req->input('date')
        ];

        $rsl = TempRoute::create($data);
        if ($rsl) {
            return response()->json(
                ['message' => 'saved', 
                'status' => true]);
        } else {
            return response()->json(
                ['message' => 'error on save', 
                'status' => false]);
        }
        

    }

    function fetch() {
        $rsl =  TempRoute::orderBy('id', 'desc')->limit(1)->first();
        return response()->json(['status' => true, 'data' => $rsl]);
    }

    function checkpoint(Request $req) {
        if ($req->input('beacon_id') == '') {
            return response()->json(['status' => false, 'message' => 'required beacon id']);
        }

        $currentPoint = TrackCheckPoint::where('beacon_id', $req->input('beacon_id'))->where('id', $req->input('checkpoint_id'))->first();

        if($currentPoint) {
            $trackCode = $currentPoint->track_code;
            $pointOrder = $currentPoint->point_order;
            $nextPointOrder = $pointOrder + 1;
            $nextPoint = TrackCheckPoint::where('track_code', $trackCode)->where('point_order', $nextPointOrder)->first();

            Patrol::create([
                'guard_id' => $req->input('guard_id'), 
                'track_code' => $req->input('track_code'), 
                'point_id' => $currentPoint->id, 
                'schedule_id' => $req->input('schedule_id'), 
                'check_in_timestamp' => $req->input('date')]
            );

            if($nextPoint) {
                
                return response()->json(['status' => true, 'data' => ['current' => $currentPoint, 'next' => $nextPoint]]);
            } else {
                return response()->json(['status' => true, 'data' => ['current' => $currentPoint, 'next' => false]]);
            }

        } else {
            return response()->json(['status' => false, 'message' => 'invalid beacon id']);
        }
    }


}
