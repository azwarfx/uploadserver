<?php

namespace App\Http\Controllers;

use Laravel\Lumen\Routing\Controller as BaseController;
use App\Guard;
use App\Cluster;
use App\Track;
use Illuminate\Http\Request;
use App\Schedule;

class UserController extends Controller
{
    function __construct() 
    {

    }

    function auth(Request $req) {
        $usr = Guard::where('username', "ILIKE", $req->input('username'))->first();
        if (!$usr) {
            return response()
            ->json(['status' => false, 'message' => 'User not found']);
        }

        $return['user'] = [ 
            'id' => $usr->id,
            'username' => $usr->username,
        ];
        $return['status'] = true;
        $return  = array_merge($return, $this->get($req->input('username')));

        return response()->json($return);
    }

    function get($username) {
        $usr = Guard::where('username', "ILIKE", $username)->first();
        if($usr) {
            $data = [];

            if ($usr->username == 'user') {

                $clusters = Cluster::get();

                foreach ($clusters as $cluster) {
                    $tracks = Track::where('cluster_code', $cluster->code)->get();
                    $data[$cluster->code] = [];
                    foreach ($tracks as $track) {

                        $temp = [
                            'code' => $track->code,
                            'name' => $track->name,
                            'coordinates' => $track->getCoordinate->toArray()
                        ];

                        $data[$cluster->code][] = $temp;

                    }

                    $dataCluster[] = [
                        'code' => $cluster->code,
                        'name' => $cluster->name,
                        'track' => $data[$cluster->code]
                    ];

                }

                return [
                    'schedule_now' => true,
                    'cluster' => $dataCluster
                ];
            }
            //find schedule
            $date = date('Y-m-d 00:00:00');
            $schedule = Schedule::where('guard_username', "ILIKE", $usr->username)->where('assign_date', $date)->get();
            $data = [];
            if ($schedule->count() > 0) {
                foreach ($schedule as $value) {
                    $temp = [
                        'code' => $value->getTrack->code,
                        'name' => $value->getTrack->name,
                        'coordinates' => $value->getTrack->getCoordinate->toArray()
                    ];
                    if (isset($data[$value->getTrack->getCluster->code])) {
                        $temp1 = $data[$value->getTrack->getCluster->code];
                        $temp1[] = $temp;
                        $data[$value->getTrack->getCluster->code] =  $temp1;
                    } else {
                        $data[$value->getTrack->getCluster->code][] = $temp;
                        $name[$value->getTrack->getCluster->code] = $value->getTrack->getCluster->name;
                    }

                }

                foreach ($data as $code => $value) {
                    $dataCluster[] = [
                        'code' => $code,
                        'name' => $name[$code],
                        'track' => $value
                    ];
                }

                return [
                    'schedule_now' => true,
                    'cluster' => $dataCluster
                ];
            } else {
                    return [
                        'message' => 'no schedule for this day', 
                        'schedule_now' => false
                    ];
            }

        } else {
            return [
                'message' => 'user not found', 
                'status' => false
            ];
         
        }
    }


}
