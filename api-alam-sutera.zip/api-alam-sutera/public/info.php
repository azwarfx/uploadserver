<?php

phpinfo();


?>
